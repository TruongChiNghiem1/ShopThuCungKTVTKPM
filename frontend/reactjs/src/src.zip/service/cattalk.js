// export const url_service_laravel = 'http://localhost:8000';
export const url_service_node = 'http://localhost:3001';
// export const url_service_spring = 'http://localhost:8080';
